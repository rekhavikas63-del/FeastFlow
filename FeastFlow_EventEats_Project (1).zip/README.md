# FeastFlow — EventEats Exchange

A small, frontend-only demo of an event catering quote builder. Built with React + Vite, with a simple responsive layout and seeded demo data.

## Features
- Guest slider from 50–500
- Course-based dish picker with search
- Veg / Jain / any-diet filters (demo filter)
- Volume discount: 5% at 100–199 guests, 10% at 200+
- Service fee and tax allowance included in the estimate
- Vendor cards and comparison view
- Tasting request form (demo state only)
- Print-friendly quotation (use browser print and choose Save as PDF)
- 10% food buffer estimate

## Run locally
1. Install Node.js (18+ recommended).
2. Unzip the project.
3. In the project folder run:

```bash
npm install
npm run dev
```

4. Open the local URL shown by Vite (usually `http://localhost:5173`).

## Build
```bash
npm run build
```

## Notes
This is a hackathon demo. Vendor ratings, prices and tasting request flow are sample data, not real bookings or verified vendors. The quotation export uses your browser's print dialog; select **Save as PDF**.
