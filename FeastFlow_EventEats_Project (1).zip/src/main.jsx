import React, { useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import {
  ArrowUpRight, CalendarDays, Check, ChefHat, ChevronDown, Clock3, Download,
  Heart, Leaf, MapPin, Minus, Plus, Search, ShieldCheck, SlidersHorizontal,
  Sparkles, Star, Users, Utensils, Wallet, X
} from 'lucide-react';
import './styles.css';

const vendors = [
  { name: 'Royal Feast Caterers', rating: '4.8', reviews: 126, minimum: 50, rate: 450, tag: 'Popular pick', accent: 'mint', about: 'Classic Indian menus, beautifully served.', location: 'Hyderabad' },
  { name: 'Spice Symphony', rating: '4.5', reviews: 89, minimum: 75, rate: 420, tag: 'Best value', accent: 'peach', about: 'Big flavours and a little modern flair.', location: 'Hyderabad' },
  { name: 'Olive & Thyme', rating: '4.7', reviews: 64, minimum: 25, rate: 510, tag: 'Premium', accent: 'lavender', about: 'Comfort food with a fresh, seasonal touch.', location: 'Secunderabad' },
];

const dishes = [
  { id: 'corn', name: 'Crispy corn', course: 'Starters', diet: 'Veg', price: 45, desc: 'Golden, crunchy and lightly spiced' },
  { id: 'paneer', name: 'Paneer tikka', course: 'Starters', diet: 'Veg', price: 65, desc: 'Char-grilled with a smoky marinade' },
  { id: 'spring', name: 'Veg spring rolls', course: 'Starters', diet: 'Veg', price: 50, desc: 'Crisp rolls with sweet chilli dip' },
  { id: 'chicken', name: 'Chicken 65', course: 'Starters', diet: 'Non-Veg', price: 80, desc: 'A crowd favourite, served hot' },
  { id: 'kebab', name: 'Chicken tikka', course: 'Starters', diet: 'Non-Veg', price: 90, desc: 'Tandoor-finished and tender' },
  { id: 'salad', name: 'Garden salad', course: 'Starters', diet: 'Veg', price: 30, desc: 'Seasonal greens and dressing' },
  { id: 'biryani', name: 'Veg dum biryani', course: 'Mains', diet: 'Veg', price: 90, desc: 'Slow-cooked rice and fragrant spices' },
  { id: 'paneer-curry', name: 'Paneer butter masala', course: 'Mains', diet: 'Veg', price: 85, desc: 'Creamy tomato gravy' },
  { id: 'dal', name: 'Dal tadka', course: 'Mains', diet: 'Veg', price: 45, desc: 'Homestyle lentils with tempering' },
  { id: 'chicken-curry', name: 'Chicken curry', course: 'Mains', diet: 'Non-Veg', price: 100, desc: 'A rich, slow-cooked curry' },
  { id: 'fried-rice', name: 'Veg fried rice', course: 'Mains', diet: 'Veg', price: 65, desc: 'Wok tossed with vegetables' },
  { id: 'naan', name: 'Butter naan', course: 'Breads', diet: 'Veg', price: 25, desc: 'Soft naan brushed with butter' },
  { id: 'roti', name: 'Tandoori roti', course: 'Breads', diet: 'Veg', price: 18, desc: 'Fresh from the tandoor' },
  { id: 'gulab', name: 'Gulab jamun', course: 'Desserts', diet: 'Veg', price: 35, desc: 'Warm, syrup-soaked classic' },
  { id: 'brownie', name: 'Chocolate brownie', course: 'Desserts', diet: 'Veg', price: 55, desc: 'Rich chocolate with a fudgy centre' },
  { id: 'icecream', name: 'Vanilla ice cream', course: 'Desserts', diet: 'Veg', price: 40, desc: 'A cool scoop to finish' },
  { id: 'fruit', name: 'Fresh fruit bowl', course: 'Desserts', diet: 'Veg', price: 45, desc: 'Seasonal fruit, simply served' },
  { id: 'chaat', name: 'Chaat counter', course: 'Live counters', diet: 'Veg', price: 75, desc: 'Made fresh as guests walk up' },
  { id: 'pasta', name: 'Pasta station', course: 'Live counters', diet: 'Veg', price: 95, desc: 'Creamy or tomato sauce, made to order' },
];

const courseOrder = ['Starters', 'Mains', 'Breads', 'Live counters', 'Desserts'];
const initialSelection = ['corn', 'paneer', 'biryani', 'paneer-curry', 'naan', 'gulab', 'brownie'];

function App() {
  const [guests, setGuests] = useState(150);
  const [eventType, setEventType] = useState('College fest');
  const [diet, setDiet] = useState('Veg');
  const [selected, setSelected] = useState(initialSelection);
  const [search, setSearch] = useState('');
  const [tastingVendor, setTastingVendor] = useState(null);
  const [tastingSent, setTastingSent] = useState(false);
  const [tastingDate, setTastingDate] = useState('');
  const [tastingVenue, setTastingVenue] = useState('');
  const [activeTab, setActiveTab] = useState('Menu builder');
  const [showCompare, setShowCompare] = useState(false);

  const selectedDishes = dishes.filter(d => selected.includes(d.id));
  const subtotal = selectedDishes.reduce((sum, d) => sum + d.price, 0);
  const discount = guests >= 200 ? .10 : guests >= 100 ? .05 : 0;
  const service = Math.round(subtotal * .08);
  const plate = Math.round((subtotal * (1 - discount) + service) * 1.05);
  const total = plate * guests;
  const buffer = Math.ceil(guests * 1.1);
  const filtered = dishes.filter(d => (!search || d.name.toLowerCase().includes(search.toLowerCase())) && (diet === 'Any diet' || d.diet === 'Veg' || diet === 'Jain'));

  const toggleDish = id => setSelected(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  const fmt = value => value.toLocaleString('en-IN');
  const quoteItems = useMemo(() => selectedDishes.map(d => `${d.name} — ₹${d.price}`), [selectedDishes]);

  function printQuote() {
    const content = document.getElementById('print-quote');
    if (!content) return;
    window.print();
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <a className="brand" href="#" aria-label="FeastFlow home">
          <span className="brand-mark"><Utensils size={19} /></span>
          <span>feastflow<span className="brand-dot">.</span></span>
        </a>
        <nav className="nav-links">
          {['Menu builder', 'Vendors', 'My quotes'].map(item => (
            <button key={item} className={activeTab === item ? 'nav-active' : ''} onClick={() => { setActiveTab(item); if(item === 'Vendors') setShowCompare(true); }}>
              {item}
            </button>
          ))}
        </nav>
        <div className="top-actions"><span className="avatar">F</span><span className="profile-name">Guest planner</span><ChevronDown size={15} /></span></div>
      </header>

      <main>
        <section className="hero">
          <div className="hero-copy">
            <div className="eyebrow"><Sparkles size={14} /> EVENT PLANNING, MADE SIMPLE</div>
            <h1>Good food. Great gathering.<br/><span>Zero budget surprises.</span></h1>
            <p>Build a menu your guests will love, get a realistic estimate, and compare trusted caterers — all in one place.</p>
            <div className="hero-meta"><span><ShieldCheck size={16}/> Verified vendors</span><span><Wallet size={16}/> Transparent pricing</span></div>
          </div>
          <div className="hero-art">
            <div className="food-plate"><div className="plate-rim"><div className="plate-food"><span className="food-leaf">✦</span><span className="food-tomato">●</span><span className="food-herb">✿</span></div></div></div>
            <div className="art-note"><span className="note-icon"><Heart size={16}/></span><div><strong>Made for your moments</strong><small>From campus fests to family celebrations</small></div></div>
            <div className="art-sticker">Freshly<br/>planned <span>✷</span></div>
          </div>
        </section>

        <section className="quick-stats">
          <div><span className="stat-icon peach-bg"><Users size={17}/></span><div><small>Guest count</small><strong>{guests} people</strong></div></div>
          <div><span className="stat-icon mint-bg"><ChefHat size={17}/></span><div><small>Menu items</small><strong>{selected.length} selected</strong></div></div>
          <div><span className="stat-icon lilac-bg"><Wallet size={17}/></span><div><small>Estimated budget</small><strong>₹{fmt(total)}</strong></div></div>
          <div className="stat-right"><span className="live-dot"></span> Live estimate</div>
        </section>

        <div className="workspace">
          <section className="menu-panel">
            <div className="section-heading">
              <div><span className="section-kicker">YOUR EVENT</span><h2>Let's set the table</h2><p>Start with the basics, then make the menu your own.</p></div>
            <div className="step-pill">01 <span>/ 03</span></div>
          </div>
            <div className="setup-grid">
              <div className="field-block">
                <label>Event type</label>
                <div className="select-wrap"><select value={eventType} onChange={e => setEventType(e.target.value)}><option>College fest</option><option>Birthday</option><option>Corporate</option><option>Wedding</option><option>Department banquet</option></select><ChevronDown size={16}/></div>
              </div>
              <div className="field-block">
                <label>Dietary preference</label>
                <div className="select-wrap"><select value={diet} onChange={e => setDiet(e.target.value)}><option>Veg</option><option>Non-Veg</option><option>Jain</option><option>Any diet</option></select><ChevronDown size={16}/></div>
              </div>
            </div>
            <div className="guest-control">
              <div className="guest-label"><label>How many guests?</label><strong>{guests} <small>guests</small></strong></div>
              <input aria-label="Guest count" type="range" min="50" max="500" step="10" value={guests} onChange={e => setGuests(Number(e.target.value))}/>
              <div className="range-labels"><span>50 guests</span><span>500 guests</span></div>
              <div className="discount-hint"><span><Sparkles size={14}/> Volume savings</span><strong>{discount * 100}% discount applied</strong></div>
            </div>
            <div className="menu-section-head">
              <div><span className="section-kicker">BUILD YOUR MENU</span><h2>Pick the crowd-pleasers</h2></div>
              <div className="searchbox"><Search size={15}/><input placeholder="Search dishes..." value={search} onChange={e => setSearch(e.target.value)}/></div>
            </div>
            {courseOrder.map(course => {
              const items = filtered.filter(d => d.course === course);
              if (!items.length) return null;
              return <div className="course-group" key={course}>
                <div className="course-title"><h3>{course}</h3><span>{selected.filter(id => items.some(d => d.id === id)).length} selected</span></div>
                <div className="dish-grid">
                  {items.map(d => {
                    const active = selected.includes(d.id);
                    return <button key={d.id} className={`dish-card ${active ? 'dish-selected' : ''}`} onClick={() => toggleDish(d.id)}>
                      <span className={`dish-icon ${d.diet === 'Non-Veg' ? 'nonveg' : ''}`}>{d.diet === 'Non-Veg' ? '●' : '✦'}</span>
                      <span className="dish-info"><strong>{d.name}</strong><small>{d.desc}</small><b>₹{d.price}<small> / plate</small></b></span>
                      <span className={`checkmark ${active ? 'checked' : ''}`}>{active ? <Check size={13}/> : <Plus size={13}/>}</span>
                    </button>
                  })}
                </div>
              </div>
            })}
            <div className="menu-footer"><span><Leaf size={15}/> Prices are indicative and may vary by vendor.</span><button onClick={() => setShowCompare(true)}>Compare vendors <ArrowUpRight size={15}/></button></div>
        </section>

        <aside className="quote-sidebar">
          <div className="quote-card">
            <div className="quote-header"><div><span className="section-kicker">YOUR ESTIMATE</span><h2>Quote summary</h2></div><span className="quote-icon"><Wallet size={18}/></span></div>
            <div className="quote-main"><strong>₹{fmt(plate)}</strong><span>per guest, approx.</span></div>
            <div className="quote-total"><span>Estimated total for {guests} guests</span><strong>₹{fmt(total)}</strong></div>
            <div className="quote-breakdown">
              <div><span>Menu selection ({selected.length} items)</span><b>₹{fmt(subtotal)}</b></div>
              <div><span>Volume discount</span><b className="green">−{Math.round(discount*100)}%</b></div>
              <div><span>Service fee (8%)</span><b>₹{fmt(service)}</b></div>
              <div><span>Estimated taxes (5%)</span><b>Included</b></div>
            </div>
            <div className="quote-footnote"><ShieldCheck size={14}/> Estimate includes service and tax allowance.</div>
            <button className="primary-button" onClick={printQuote}><Download size={16}/> Export quotation</button>
            <button className="secondary-button" onClick={() => setShowCompare(true)}>Compare caterers <ArrowUpRight size={16}/></button>
          </div>
          <div className="buffer-card"><div className="buffer-icon"><ChefHat size={17}/></div><div><strong>Plan a little extra</strong><p>With a 10% buffer, plan portions for <b>{buffer} guests</b> so no one misses out.</p></div></div>
          <div className="trust-note"><ShieldCheck size={17}/><div><strong>Food you can feel good about</strong><p>We list vendors with hygiene checks and verified customer reviews.</p></div></div>
        </aside>
      </div>

      <section className="vendors-section">
        <div className="section-heading compact"><div><span className="section-kicker">OUR CATERERS</span><h2>Good food, good people</h2><p>A few local favourites to get you started.</p></div><button className="text-button" onClick={() => setShowCompare(true)}>Compare all <ArrowUpRight size={15}/></button></div>
        <div className="vendor-grid">
          {vendors.map(v => <article className={`vendor-card ${v.accent}`} key={v.name}>
            <div className="vendor-top"><span className="vendor-tag">{v.tag}</span><button className="heart-button" aria-label="Save vendor"><Heart size={16}/></button></div>
            <div className="vendor-illustration"><div className="v-plate"><span>✦</span></div><div className="v-leaf">✿</div><div className="v-cutlery">⌁</div></div>
            <div className="vendor-content"><div className="vendor-title"><h3>{v.name}</h3><span><Star size={13} fill="currentColor"/> {v.rating}</span></div><p>{v.about}</p><div className="vendor-details"><span><MapPin size={13}/> {v.location}</span><span><Users size={13}/> Min. {v.minimum}</span></div><div className="vendor-bottom"><div><strong>₹{v.rate}</strong><small>/ plate from</small></div><button onClick={() => {setTastingVendor(v);setTastingSent(false)}}>Book tasting <ArrowUpRight size={14}/></button></div></div>
          </article>)}
        </div>
      </section>
      <footer><span className="brand small"><span className="brand-mark"><Utensils size={15}/></span> feastflow<span className="brand-dot">.</span></span><p>Planning should be the fun part. © 2025 FeastFlow</p><span>Made with care, served with flavour.</span></footer>
    </main>

    {showCompare && <div className="modal-backdrop" onClick={() => setShowCompare(false)}><div className="modal compare-modal" onClick={e => e.stopPropagation()}>
      <div className="modal-head"><div><span className="section-kicker">VENDOR SHORTLIST</span><h2>Compare your options</h2><p>Same guest count, clearer choices.</p></div><button className="close-button" onClick={() => setShowCompare(false)}><X size={18}/></button></div>
      <div className="compare-table"><div className="compare-row compare-head"><span>Vendor</span><span>Rating</span><span>Starting price</span><span>Est. total*</span></div>{vendors.map(v=><div className="compare-row" key={v.name}><span className="compare-name">{v.name}<small>Min. {v.minimum} guests</small></span><span><Star size={13} fill="currentColor"/> {v.rating}</span><span>₹{v.rate}/plate</span><strong>₹{fmt(v.rate*guests)}</strong></div>)}</div><p className="compare-note">*Vendor totals are quick baseline estimates and don't include your custom menu. Final quotes may vary.</p><div className="modal-actions"><button className="secondary-button" onClick={() => setShowCompare(false)}>Back to menu</button><button className="primary-button" onClick={() => {setShowCompare(false);setTastingVendor(vendors[0]);}}>Book a tasting <CalendarDays size={15}/></button></div>
    </div></div>}

    {tastingVendor && <div className="modal-backdrop" onClick={() => setTastingVendor(null)}><div className="modal tasting-modal" onClick={e => e.stopPropagation()}>
      <div className="modal-head"><div><span className="section-kicker">TASTING REQUEST</span><h2>{tastingSent ? 'Request received!' : `Meet ${tastingVendor.name}`}</h2><p>{tastingSent ? 'Your request is saved in this demo.' : 'Pick a date and we’ll get the ball rolling.'}</p></div><button className="close-button" onClick={() => setTastingVendor(null)}><X size={18}/></button></div>
      {tastingSent ? <div className="success-message"><span className="success-check"><Check size={24}/></span><strong>All set, for now.</strong><p>This demo has saved your tasting request on screen. The caterer would follow up to confirm the slot.</p><button className="primary-button" onClick={() => setTastingVendor(null)}>Done</button></div> : <form className="tasting-form" onSubmit={e => {e.preventDefault();setTastingSent(true)}}><label>Preferred date<input type="date" required value={tastingDate} onChange={e => setTastingDate(e.target.value)} min={new Date().toISOString().slice(0,10)}/></label><label>Venue or area<input required placeholder="e.g. College campus, Hyderabad" value={tastingVenue} onChange={e => setTastingVenue(e.target.value)}/></label><div className="tasting-vendor-line"><span>Selected caterer</span><strong>{tastingVendor.name}</strong></div><button className="primary-button" type="submit">Send tasting request <ArrowUpRight size={15}/></button></form>}
    </div></div>}

    <div id="print-quote" className="print-only"><h1>FeastFlow — Catering Estimate</h1><p>{eventType} · {guests} guests</p><h2>Selected menu</h2><ul>{quoteItems.map((item,i)=><li key={i}>{item}</li>)}</ul><p>Subtotal per plate: ₹{subtotal}</p><p>Volume discount: {Math.round(discount*100)}%</p><p>Service fee (8%): ₹{service}</p><h2>Estimated per plate: ₹{plate}</h2><h2>Estimated total: ₹{fmt(total)}</h2><p>Prices are indicative. Confirm final rates and inclusions with your caterer.</p></div>
  </div>
  );
}

createRoot(document.getElementById('root')).render(<App />);
